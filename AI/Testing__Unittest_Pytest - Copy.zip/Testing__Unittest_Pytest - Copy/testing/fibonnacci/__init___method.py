'''
https://realpython.com/python-class-constructor/
'''